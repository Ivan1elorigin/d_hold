#pragma once



//Librer�as
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE* fichero; //Esto se ponde despu�s de la �ltima biblioteca y antes de los prototipos.

#define E 4
#define P 6
#define S 50

// Introduce el nombre. Introduce votos. El partido seleccionado cumple con la condici�n del 3%.
// Despu�s introduzca el nombre.
// Prototipos.

void limpiamos_tabla(float[P][E], int[2][P]); // Esta funci�n la utilizamos para limpiar la tabla en la que vamos a aplicar la f�rmula a los votos de cada partido.

void introducimos_partidos(float[P][E], float); // Esta funci�n pide a los usuarios los votos que ha recivido cada partido y los escribe en la tabla. Tambi�n aplica el filtro del 3% que meciona el art�culo del "ABC".

void divide_votos(float[P][E]); // Aplica el sistema d'Hont a la tabla.

void imprime(float[P][E], int[2][P]); // Imprime la tabla

void escanos_conce(float[P][E], int[2][P]); //Introduce los resultados en una tabla de resultados.

void resultado(int[2][P]);