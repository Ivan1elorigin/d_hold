/*
He intentado crear un programa para aplicar el sistema d'Hont el cual es utilizado para realizar la asignaci�n de esca�os despu�s de las elecciones genereales.

https://www.abc.es/elecciones/elecciones-generales/abci-y-como-funciona-ley-dhont-201911090957_noticia.html

*/

#include "header.h"

//main

int main() {
	float tabla[P][E], escanos = E, votos_totales=0;
	int tabla_escanos[2][P];
	char provincia[S];
	//Esto tendre que hacerlo m�s adelante.
	//printf("Introduzca el nombre de la provincia");
	//gets_s(provincia);
	//provincia = provincia + ".txt";
	fopen_s(&fichero, "Cuenca.txt", "w + "); //w+ si el fichero no est� crearlo lo crea y con los permisos leer/escribir.
	limpiamos_tabla(tabla, tabla_escanos);

	printf("Introduzca el numero de votos totales.\n");
	scanf_s("%f", &votos_totales);
	
	introducimos_partidos(tabla, votos_totales);
	divide_votos(tabla);
	imprime(tabla, tabla_escanos);
	
	//Cogemos los n�meros m�s grandes y vamos viendo de qu� partido son para ir a�adi�ndole un esca�o a cada uno.

	escanos_conce(tabla, tabla_escanos);

	imprime(tabla, tabla_escanos);

	resultado(tabla_escanos);

	fclose(fichero); // Es importante ir cerrando las direcciones de memoria que vamos creando para que no saturen la memoria.
	system("pause");
	return 0;
}

