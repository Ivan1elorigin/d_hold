#include "header.h"

//funciones

void limpiamos_tabla(float tabla[P][E], int tabla_escanos[2][P]) {
	int i, j;

	for (i = 0; i < P; i++) { //El n�mero de filas corresponde a los partidos pol�ticos.
		for (j = 0; j < E; j++) { //El n�mero de columnas corresponde a los esca�os a repartir.
			tabla[i][j] = 0; //Para limpiar la tabla empezamos
		}
	}
	// Nos movemos por las filar
	// Nos movemos por las columnas.
	
	for (i = 0; i < P; i++) {
		tabla_escanos[0][i] = (i + 1);
	}
	for (i = 0; i < P; i++) {
		tabla_escanos[1][i] = (0);
	}

}

void introducimos_partidos(float tabla[P][E], float votos_totales) {
	float votosxpartido = 0;
	int i;


	printf("\nIntroduzca en el sistema los datos de los partidos\n");

	for (i = 0; i < P; i++) {
		printf("\nIntroduzca los votos que a obtenido el partido\n");
		scanf_s("%f", &votosxpartido);

		if (((votosxpartido / votos_totales) * 100) > 3) {
			tabla[i][0] = votosxpartido; //Si los votos han superado el 3% del total, que me los guarde en la primera columna.


		}
		else {
			printf("\nLo siento los votos del partido no han superado al 3 por ciento del total.\n");
		}
		votosxpartido = 0;
	}

}

void divide_votos(float tabla[P][E]) {
	int i, j;

	for (i = 1; i < E; i++) {
		for (j = 0; j < P; j++) {
			tabla[j][i] = (tabla[j][0] / (i + 1)); //En la columna 1 queremos que el n�mero de la columna 0 est� dividido entre dos y as� continuamente.
		}

	}
}

void imprime(float tabla[P][E], int tabla_escanos[2][P]) {
	int i, j;

	for (i = 0; i < P; i++) {
		printf(" %d ", i + 1);
		for (j = 0; j < E; j++) {
			printf("| %f |", tabla[i][j]);
		}
		printf("\n");
	}

	printf("\n\n\n");

	for (i = 0; i < 2; i++) {
		for (j = 0; j < P; j++) {
			printf("| %d |", tabla_escanos[i][j]);
		}
		printf("\n");
	}
}

void escanos_conce(float tabla[P][E], int tabla_escanos[2][P]) {
	int i = 0, j = 0, n = 0, auxi = 0, auxj = 0;
	float max = 0;
	//Quiero saber cuales son los n�meros m�s grandes de la tabla.
	for (n = 0; n < E; n++) {
		//De la tabla, hacemos la selecci�n del m�s grande y guardamos su posici�n con auxi y auxj.
		for (i = 0; i < P; i++) {
			for (j = 0; j < E; j++) {
				if (tabla[i][j] > max) {
					max = tabla[i][j];
					auxi = i;
					auxj = j;

					

				}


			}
		} // Una vez hemos finalizado la selecci�n del m�s grande, lo borramos y a�adimos un esca�o a su correspondiente casilla de tabla_escanos.
		tabla[auxi][auxj] = 0;
		tabla_escanos[1][auxi] += 1;
		//Limpiamos max, auxi y auxj.

		auxi = 0;
		auxj = 0;
		max = 0;
	}
}

void resultado(int tabla_escanios[2][P]) {
	int i;
	for (i = 0; i < P; i++) {
		printf("\nEl partido %d ha obtenido %d escanios.\n", (i+1), tabla_escanios[1][i]);
	}
}


